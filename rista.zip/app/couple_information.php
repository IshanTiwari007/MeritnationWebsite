<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class couple_information extends Model
{
    //
}
