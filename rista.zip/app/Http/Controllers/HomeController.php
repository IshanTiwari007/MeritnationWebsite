<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\couple_information;
use App\gallery;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $couple=couple_information::orderBy('id','DESC')->limit(9)->get();
        $Gallery=gallery::orderBy('id','DESC')->limit(5)->get();
        return view('index')
        ->with('couple',$couple)
        ->with('gallery',$Gallery);
    }
    public function form()
    {
        return view('Form');
    }
    public function detail()
    {
        return view('index');
    }
}
