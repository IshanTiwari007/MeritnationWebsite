<!DOCTYPE html>
<html lang="zxx">
<head>
	<?php echo $__env->make('Frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="51">

	<!-- Header -->
	<?php echo $__env->make('Frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--/ End Header -->


	<?php echo $__env->yieldContent('main-content'); ?>
	

	<!-- footer -->
	<?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--  End of footer -->

</body>
</html><?php /**PATH D:\Ishan\Projects\Project7\RistaOnline\resources\views/Frontend/layouts/main.blade.php ENDPATH**/ ?>